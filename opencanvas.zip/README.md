# 🎨 OpenCanvas

Open-source, community-owned design platform inspired by Canva.
